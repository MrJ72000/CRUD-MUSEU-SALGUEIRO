/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salgas_museu.dao;
import java.sql.*;
/**
 *
 * @author Aluno
 */
//metodo responsavel para estabelecer a conexão.
public class Conecty {
  public static Connection conector (){ 
  java.sql.Connection conexao = null;  
  
//Drive, URL, User e Password
String driver = "com.mysql.jdbc.Driver ";
String url = "jdbc:mysql://127.0.0.1:3306/salagas_museu?UseTimeZone=true&serverTimeZone=UTC";
String user = "root";
String password = "20077200";

//estabelendo conexão com o banco.

try {
    Class.forName( driver);
    conexao = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/salagas_museu?UseTimeZone=true&serverTimeZone=UTC", "root","20077200");
    return conexao;
}catch (Exception e){
    e.getMessage();
    e.getStackTrace();
    return null;
    }
  }

    PreparedStatement PreparedStatement(String sql) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
