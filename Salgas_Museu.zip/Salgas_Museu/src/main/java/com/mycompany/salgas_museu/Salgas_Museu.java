/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.salgas_museu;

/**
 *
 * @author Aluno
 */
public class Salgas_Museu {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
